-- --------------------------------------------------------
-- Máy chủ:                      127.0.0.1
-- Server version:               10.4.32-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Phiên bản:           12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table 123web.admin
CREATE TABLE IF NOT EXISTS `admin` (
  `maadmin` varchar(255) NOT NULL,
  `hoten` varchar(255) NOT NULL,
  `gioitinh` varchar(255) NOT NULL,
  `diachi` varchar(255) NOT NULL,
  `sodienthoai` varchar(255) NOT NULL,
  `ngaysinh` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `matkhau` varchar(255) NOT NULL,
  PRIMARY KEY (`maadmin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table 123web.giangvien
CREATE TABLE IF NOT EXISTS `giangvien` (
  `magiangvien` varchar(255) NOT NULL,
  `tengiangvien` varchar(255) NOT NULL,
  `ngaysinh` date NOT NULL,
  `gioitinh` varchar(255) NOT NULL DEFAULT '0',
  `diachi` varchar(255) NOT NULL,
  `sodienthoai` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `chuyennganh` varchar(255) NOT NULL,
  `matkhau` varchar(255) NOT NULL,
  PRIMARY KEY (`magiangvien`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table 123web.hocphan
CREATE TABLE IF NOT EXISTS `hocphan` (
  `mahocphan` varchar(255) NOT NULL,
  `tenhocphan` varchar(255) NOT NULL DEFAULT '',
  `tinchi` int(11) NOT NULL DEFAULT 0,
  `hocky` varchar(255) NOT NULL DEFAULT '',
  `manganh` varchar(255) NOT NULL DEFAULT '',
  `batbuoc` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`mahocphan`),
  KEY `FK_hocphan_nganh` (`manganh`),
  CONSTRAINT `FK_hocphan_nganh` FOREIGN KEY (`manganh`) REFERENCES `nganh` (`manganh`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table 123web.khoa
CREATE TABLE IF NOT EXISTS `khoa` (
  `makhoa` varchar(255) NOT NULL,
  `tenkhoa` varchar(255) NOT NULL,
  PRIMARY KEY (`makhoa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table 123web.lop
CREATE TABLE IF NOT EXISTS `lop` (
  `malop` varchar(255) NOT NULL,
  `tenlop` varchar(255) NOT NULL,
  `covanhoctap` varchar(255) NOT NULL,
  `khoa` varchar(255) NOT NULL,
  `manganh` varchar(255) NOT NULL,
  PRIMARY KEY (`malop`),
  KEY `FK_lop_nganh` (`manganh`),
  CONSTRAINT `FK_lop_nganh` FOREIGN KEY (`manganh`) REFERENCES `nganh` (`manganh`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table 123web.lophoc
CREATE TABLE IF NOT EXISTS `lophoc` (
  `malophoc` varchar(255) NOT NULL,
  `tenlophoc` varchar(255) NOT NULL,
  `toanha` varchar(255) NOT NULL,
  `phong` varchar(255) NOT NULL,
  PRIMARY KEY (`malophoc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table 123web.monhoc
CREATE TABLE IF NOT EXISTS `monhoc` (
  `mamonhoc` varchar(255) NOT NULL,
  `tenmonhoc` varchar(255) NOT NULL,
  `ngaybatdau` varchar(255) NOT NULL,
  `ngayketthuc` varchar(255) NOT NULL,
  `giobatdau` varchar(255) NOT NULL,
  `gioketthuc` varchar(255) NOT NULL,
  `lichhoc` varchar(255) NOT NULL,
  `mahocphan` varchar(255) NOT NULL,
  `magiangvien` varchar(255) NOT NULL,
  `malop` varchar(255) NOT NULL,
  `malophoc` varchar(255) NOT NULL,
  PRIMARY KEY (`mamonhoc`),
  KEY `FK_monhoc_hocphan` (`mahocphan`),
  KEY `FK_monhoc_giangvien` (`magiangvien`),
  KEY `FK_monhoc_lop` (`malop`),
  KEY `FK_monhoc_lophoc` (`malophoc`),
  CONSTRAINT `FK_monhoc_giangvien` FOREIGN KEY (`magiangvien`) REFERENCES `giangvien` (`magiangvien`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_monhoc_hocphan` FOREIGN KEY (`mahocphan`) REFERENCES `hocphan` (`mahocphan`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_monhoc_lop` FOREIGN KEY (`malop`) REFERENCES `lop` (`malop`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_monhoc_lophoc` FOREIGN KEY (`malophoc`) REFERENCES `lophoc` (`malophoc`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table 123web.nganh
CREATE TABLE IF NOT EXISTS `nganh` (
  `manganh` varchar(255) NOT NULL,
  `tennganh` varchar(255) NOT NULL,
  `makhoa` varchar(255) NOT NULL,
  PRIMARY KEY (`manganh`),
  KEY `FK__khoa` (`makhoa`),
  CONSTRAINT `FK__khoa` FOREIGN KEY (`makhoa`) REFERENCES `khoa` (`makhoa`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

-- Dumping structure for table 123web.sinhvien
CREATE TABLE IF NOT EXISTS `sinhvien` (
  `masinhvien` varchar(255) NOT NULL,
  `tensinhvien` varchar(255) NOT NULL,
  `ngaysinh` varchar(255) NOT NULL,
  `gioitinh` varchar(255) NOT NULL,
  `diachi` varchar(255) NOT NULL,
  `sodienthoai` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `malop` varchar(255) NOT NULL,
  PRIMARY KEY (`masinhvien`),
  KEY `FK__lop` (`malop`),
  CONSTRAINT `FK__lop` FOREIGN KEY (`malop`) REFERENCES `lop` (`malop`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data exporting was unselected.

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
